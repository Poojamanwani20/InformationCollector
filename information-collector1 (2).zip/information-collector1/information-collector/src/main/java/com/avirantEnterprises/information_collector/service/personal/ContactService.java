package com.avirantEnterprises.information_collector.service.personal;

import com.avirantEnterprises.information_collector.model.personal.Contact;
import com.avirantEnterprises.information_collector.repository.personal.ContactRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Service
public class ContactService {

    @Autowired
    private ContactRepository contactRepository;

    private final String uploadDir = "uploads/";

    public void registerContact(String name, String email, String phone, String message, MultipartFile document) {
        String documentPath = null;

        try {
            // Handle file upload
            if (!document.isEmpty()) {
                File uploadDirFile = new File(uploadDir);
                if (!uploadDirFile.exists()) uploadDirFile.mkdirs();
                documentPath = uploadDir + document.getOriginalFilename();
                document.transferTo(new File(documentPath));
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to upload document");
        }

        Contact contact = new Contact();
        contact.setName(name);
        contact.setEmail(email);
        contact.setPhone(phone);
        contact.setMessage(message);
        contact.setDocumentPath(documentPath);

        contactRepository.save(contact);
    }

    public List<Contact> getAllContacts() {
        return contactRepository.findAll();
    }

    public Contact getContactById(Long id) {
        return contactRepository.findById(id).orElse(null);
    }

    public void updateContactProfile(Long id, String name, String email, String phone, String message, MultipartFile document) {
        Contact contact = contactRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Contact not found with ID: " + id));

        String documentPath = contact.getDocumentPath();

        try {
            // Handle file upload
            if (!document.isEmpty()) {
                File uploadDirFile = new File(uploadDir);
                if (!uploadDirFile.exists()) uploadDirFile.mkdirs();
                documentPath = uploadDir + document.getOriginalFilename();
                document.transferTo(new File(documentPath));
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to upload document");
        }

        contact.setName(name);
        contact.setEmail(email);
        contact.setPhone(phone);
        contact.setMessage(message);
        contact.setDocumentPath(documentPath);

        contactRepository.save(contact);
    }

    public void deleteContactById(Long id) {
        contactRepository.deleteById(id);
    }
}
