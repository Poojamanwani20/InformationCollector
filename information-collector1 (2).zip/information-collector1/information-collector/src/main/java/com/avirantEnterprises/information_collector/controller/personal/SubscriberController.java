package com.avirantEnterprises.information_collector.controller.personal;

import com.avirantEnterprises.information_collector.model.personal.Subscriber;
import com.avirantEnterprises.information_collector.service.personal.SubscriberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Controller
public class SubscriberController {

    @Autowired
    private SubscriberService subscriberService;

    /**
     * Display the subscription form.
     */
    @GetMapping("/subscription_form")
    public String showSubscriptionForm(Model model) {
        model.addAttribute("subscriber", new Subscriber()); // Pass an empty Subscriber object
        return "personal/subscription_form"; // The view that displays the form
    }

    /**
     * Register a new subscriber.
     */
    @PostMapping("/subscribe")
    public String registerSubscriber(@RequestParam("fullName") String fullName,
                                     @RequestParam("email") String email,
                                     @RequestParam("preferences") String preferences,
                                     @RequestParam("avatar") MultipartFile avatar,
                                     Model model) {
        try {
            subscriberService.registerSubscriber(fullName, email, preferences, avatar);
            return "redirect:/subscribers"; // Redirect to the subscriber list after successful registration
        } catch (Exception e) {
            model.addAttribute("error", "Failed to register subscriber: " + e.getMessage());
            return "personal/subscription_form"; // Return to form with error message
        }
    }

    /**
     * View a specific subscriber profile.
     */
    @GetMapping("/subscriber/{id}")
    public String viewSubscriberProfile(@PathVariable("id") Long id, Model model) {
        Subscriber subscriber = subscriberService.getSubscriberById(id);
        if (subscriber == null) {
            model.addAttribute("error", "Subscriber not found with ID: " + id);
            return "personal/subscriber_not_found"; // Custom error page for missing subscriber
        }
        model.addAttribute("subscriber", subscriber);
        return "personal/subscriber_view"; // View to display the subscriber profile
    }

    /**
     * Delete a subscriber profile.
     */
    @GetMapping("/subscriber/delete/{id}")
    public String deleteSubscriberProfile(@PathVariable("id") Long id, Model model) {
        try {
            subscriberService.deleteSubscriberById(id);
            return "redirect:/subscribers"; // Redirect to the subscriber list after successful deletion
        } catch (Exception e) {
            model.addAttribute("error", "Failed to delete subscriber with ID: " + id);
            return "personal/subscriber_list"; // Return to list with error message
        }
    }

    /**
     * List all subscribers.
     */
    @GetMapping("/subscribers")
    public String listSubscribers(Model model) {
        List<Subscriber> subscribers = subscriberService.getAllSubscribers();
        model.addAttribute("subscribers", subscribers);
        return "personal/subscriber_list"; // View to display the list of subscribers
    }

    /**
     * Show the update form for a subscriber profile.
     */
    @GetMapping("/subscriber/update/{id}")
    public String showUpdateSubscriberForm(@PathVariable("id") Long id, Model model) {
        Subscriber subscriber = subscriberService.getSubscriberById(id);
        if (subscriber == null) {
            model.addAttribute("error", "Subscriber not found with ID: " + id);
            return "personal/subscriber_not_found"; // Custom error page for missing subscriber
        }
        model.addAttribute("subscriber", subscriber);
        return "personal/subscriber_update"; // View to display the update form
    }

    /**
     * Update a subscriber profile.
     */
    @PostMapping("/subscriber/update")
    public String updateSubscriber(@RequestParam("id") Long id,
                                   @RequestParam("fullName") String fullName,
                                   @RequestParam("email") String email,
                                   @RequestParam("preferences") String preferences,
                                   @RequestParam("avatar") MultipartFile avatar,
                                   Model model) {
        try {
            subscriberService.updateSubscriberProfile(id, fullName, email, preferences, avatar);
            return "redirect:/subscriber/" + id; // Redirect to the updated subscriber profile
        } catch (Exception e) {
            model.addAttribute("error", "Failed to update subscriber: " + e.getMessage());
            return "personal/subscriber_update"; // Return to form with error message
        }
    }
}
