package com.avirantEnterprises.information_collector.controller.personal;

import com.avirantEnterprises.information_collector.model.personal.User;
import com.avirantEnterprises.information_collector.service.personal.RegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.time.LocalDate;
import java.util.List;

@Controller
public class UserProfileController {

    @Autowired
    private RegistrationService registrationService;

    // View a specific user profile
    @GetMapping("/profile/{id}")
    public String viewUserProfile(@PathVariable("id") Long id, Model model) {
        User user = registrationService.getUserById(id);
        if (user == null) {
            throw new RuntimeException("User not found for id: " + id);
        }
        System.out.println("Profile Picture Path: " + user.getProfilePicPath());
        model.addAttribute("user", user);
        return "personal/profile_view";
    }

    // Delete a user profile
    @GetMapping("/profile/delete/{id}")
    public String deleteUserProfile(@PathVariable("id") Long id) {
        registrationService.deleteUserById(id);
        return "redirect:/profiles"; // Redirect to the profile list
    }

    // List all user profiles
    @GetMapping("/profiles")
    public String listUserProfiles(Model model) {
        List<User> users = registrationService.getAllUsers();
        model.addAttribute("users", users);
        return "personal/profile_list";
    }

    // Show the update form for a user profile
    @GetMapping("/profile/update/{id}")
    public String showUpdateProfileForm(@PathVariable("id") Long id, Model model) {
        User user = registrationService.getUserById(id);
        if (user == null) {
            throw new RuntimeException("User not found for id: " + id);
        }
        model.addAttribute("user", user);
        return "personal/profile_update";
    }

    // Update a user profile
    @PostMapping("/updateProfile")
    public String updateProfile(@RequestParam("id") Long id,
                                @RequestParam("name") String name,
                                @RequestParam("dob") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate dob,
                                @RequestParam("contact") String contact,
                                @RequestParam("profilePic") MultipartFile profilePic) {
        registrationService.updateUserProfile(id, name, dob, contact, profilePic);
        return "redirect:/profile/" + id; // Redirect to the updated profile page
    }
}
