package com.avirantEnterprises.information_collector.service.personal;

import com.avirantEnterprises.information_collector.model.personal.Survey;
import com.avirantEnterprises.information_collector.repository.personal.SurveyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Service
public class SurveyService {

    @Autowired
    private SurveyRepository surveyRepository;

    private final Path rootLocation = Paths.get("survey-upload-dir");

    public void createSurvey(String name, String email, String feedback, MultipartFile feedbackFile) {
        Survey survey = new Survey();
        survey.setName(name);
        survey.setEmail(email);
        survey.setFeedback(feedback);

        if (feedbackFile != null && !feedbackFile.isEmpty()) {
            String filePath = saveFile(feedbackFile);
            survey.setFilePath(filePath);
        }

        surveyRepository.save(survey);
    }

    public void updateSurvey(Long id, String name, String email, String feedback, MultipartFile feedbackFile) {
        Survey survey = surveyRepository.findById(id).orElseThrow(() -> new RuntimeException("Survey not found"));
        survey.setName(name);
        survey.setEmail(email);
        survey.setFeedback(feedback);

        if (feedbackFile != null && !feedbackFile.isEmpty()) {
            String filePath = saveFile(feedbackFile);
            survey.setFilePath(filePath);
        }

        surveyRepository.save(survey);
    }

    public Survey getSurveyById(Long id) {
        return surveyRepository.findById(id).orElse(null);
    }

    public List<Survey> getAllSurveys() {
        return surveyRepository.findAll();
    }

    public void deleteSurveyById(Long id) {
        surveyRepository.deleteById(id);
    }

    private String saveFile(MultipartFile file) {
        try {
            Files.createDirectories(rootLocation);
            String sanitizedFileName = sanitizeFileName(file.getOriginalFilename());
            Path destinationFile = rootLocation.resolve(sanitizedFileName).normalize().toAbsolutePath();
            file.transferTo(destinationFile);
            return sanitizedFileName;
        } catch (IOException e) {
            throw new RuntimeException("Failed to store file.", e);
        }
    }

    private String sanitizeFileName(String fileName) {
        return fileName.replaceAll("[^a-zA-Z0-9\\.\\-]", "_");
    }
}
