package com.avirantEnterprises.information_collector.controller.personal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class DasboardControllerPooja {

    @GetMapping("/dashboard")  // Maps to the Dashboard page
    public String dashboard(Model model) {
        // Add any data you need to pass to the view
        return "Dashboard";  // Ensure "Dashboard.html" exists in templates
    }

    @GetMapping("/add-information")  // Maps to the Add Information page
    public String addInformation(Model model) {
        // Add any data you need to pass to the view
        return "AddInformation";  // Ensure "AddInformation.html" exists in templates
    }

    @GetMapping("/view-information")  // Maps to the View Information page
    public String viewInformation(Model model) {
        // Add any data you need to pass to the view
        return "ViewInformation";  // Ensure "ViewInformation.html" exists in templates
    }

    @GetMapping("/users")  // Maps to the User Management page
    public String users(Model model) {
        // Add any data you need to pass to the view
        return "UserManagement";  // Ensure "UserManagement.html" exists in templates
    }

    @GetMapping("/settings")  // Maps to the Settings page
    public String settings(Model model) {
        // Add any data you need to pass to the view
        return "Settings";  // Ensure "Settings.html" exists in templates
    }

    @GetMapping("/logout")  // Maps to the Logout page
    public String logout(Model model) {
        // Add any data you need to pass to the view
        return "Logout";  // Ensure "Logout.html" exists in templates
    }

    @GetMapping("/register")  // Maps to the Registration Form page
    public String registerForm(Model model) {
        // Add any data you need to pass to the view
        return "/personal/registration";  // Ensure "RegisterForm.html" exists in templates
    }

    @GetMapping("/contact")  // Maps to the Contact Information Form page
    public String contactForm(Model model) {
        // Add any data you need to pass to the view
        return "/personal/contact_form";  // Ensure "ContactForm.html" exists in templates
    }

    @GetMapping("/subscribe")  // Maps to the Subscription Form page
    public String subscribeForm(Model model) {
        // Add any data you need to pass to the view
        return "/personal/Subscription_form";  // Ensure "SubscribeForm.html" exists in templates
    }

    @GetMapping("/submit")  // Maps to the Survey Form page
    public String surveyForm(Model model) {
        // Add any data you need to pass to the view
        return "/personal/survey_form";  // Ensure "SurveyForm.html" exists in templates
    }
}
