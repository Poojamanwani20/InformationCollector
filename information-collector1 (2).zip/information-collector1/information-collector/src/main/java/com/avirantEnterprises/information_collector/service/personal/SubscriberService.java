package com.avirantEnterprises.information_collector.service.personal;

import com.avirantEnterprises.information_collector.model.personal.Subscriber;
import com.avirantEnterprises.information_collector.repository.personal.SubscriberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Service
public class SubscriberService {

    @Autowired
    private SubscriberRepository subscriberRepository;

    // Define the path where the files will be saved
    private final String uploadDir = "C:/uploads/subscribers/";

    /**
     * Register a new subscriber.
     */
    public void registerSubscriber(String fullName, String email, String preferences, MultipartFile avatar) {
        String avatarPath = null;

        try {
            // Ensure the upload directory exists
            File uploadDirFile = new File(uploadDir);
            if (!uploadDirFile.exists()) {
                boolean dirCreated = uploadDirFile.mkdirs();  // Create directories if they don't exist
                if (!dirCreated) {
                    throw new IOException("Failed to create upload directory.");
                }
            }

            // Handle file upload
            if (!avatar.isEmpty()) {
                avatarPath = uploadDir + avatar.getOriginalFilename();
                File destinationFile = new File(avatarPath);
                avatar.transferTo(destinationFile);  // Save the file
            }

        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to upload avatar: " + e.getMessage());
        }

        // Create and save the subscriber object
        Subscriber subscriber = new Subscriber();
        subscriber.setFullName(fullName);
        subscriber.setEmail(email);
        subscriber.setPreferences(preferences);
        subscriber.setAvatarPath(avatarPath);

        subscriberRepository.save(subscriber);
    }

    /**
     * Retrieve all subscribers.
     */
    public List<Subscriber> getAllSubscribers() {
        return subscriberRepository.findAll();
    }

    /**
     * Retrieve a subscriber by ID.
     */
    public Subscriber getSubscriberById(Long id) {
        return subscriberRepository.findById(id).orElse(null);
    }

    /**
     * Update a subscriber profile.
     */
    public void updateSubscriberProfile(Long id, String fullName, String email, String preferences, MultipartFile avatar) {
        Subscriber subscriber = subscriberRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Subscriber not found with ID: " + id));

        String avatarPath = subscriber.getAvatarPath();  // Retain current avatar path if no new avatar is uploaded

        try {
            // Handle file upload if avatar is provided
            if (!avatar.isEmpty()) {
                // Ensure the upload directory exists
                File uploadDirFile = new File(uploadDir);
                if (!uploadDirFile.exists()) {
                    boolean dirCreated = uploadDirFile.mkdirs();
                    if (!dirCreated) {
                        throw new IOException("Failed to create upload directory.");
                    }
                }

                avatarPath = uploadDir + avatar.getOriginalFilename();
                File destinationFile = new File(avatarPath);
                avatar.transferTo(destinationFile);  // Save the new avatar
            }

        } catch (IOException e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to upload avatar: " + e.getMessage());
        }

        // Update the subscriber object
        subscriber.setFullName(fullName);
        subscriber.setEmail(email);
        subscriber.setPreferences(preferences);
        subscriber.setAvatarPath(avatarPath);

        subscriberRepository.save(subscriber);
    }

    /**
     * Delete a subscriber by ID.
     */
    public void deleteSubscriberById(Long id) {
        subscriberRepository.deleteById(id);
    }
}
