package com.avirantEnterprises.information_collector.repository.personal;

import org.springframework.data.jpa.repository.JpaRepository;
import com.avirantEnterprises.information_collector.model.personal.Subscriber;

public interface SubscriberRepository extends JpaRepository<Subscriber, Long> {
}
