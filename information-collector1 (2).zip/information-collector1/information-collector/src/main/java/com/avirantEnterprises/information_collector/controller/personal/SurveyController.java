package com.avirantEnterprises.information_collector.controller.personal;

import com.avirantEnterprises.information_collector.model.personal.Survey;
import com.avirantEnterprises.information_collector.service.personal.SurveyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Controller
public class SurveyController {

    @Autowired
    private SurveyService surveyService;

    @GetMapping("/survey_form")
    public String showSurveyForm(Model model) {
        model.addAttribute("survey", new Survey());
        return "personal/survey_form"; // View for survey submission form
    }

    @PostMapping("/submit")
    public String submitSurvey(@RequestParam("name") String name,
                               @RequestParam("email") String email,
                               @RequestParam("feedback") String feedback,
                               @RequestParam("feedbackFile") MultipartFile feedbackFile) {
        surveyService.createSurvey(name, email, feedback, feedbackFile);
        return "redirect:/surveys"; // Redirect to list of surveys
    }

    @GetMapping("/surveys")
    public String listSurveys(Model model) {
        List<Survey> surveys = surveyService.getAllSurveys();
        model.addAttribute("surveys", surveys);
        return "personal/survey_list"; // View for displaying survey list
    }

  /*  @GetMapping("/survey/{id}")
    public String viewSurvey(@PathVariable("id") Long id, Model model) {
        Survey survey = surveyService.getSurveyById(id);
        if (survey == null) {
            model.addAttribute("error", "Survey not found with ID: " + id);
            return "personal/contact_not_found"; // Custom 404 page
        }
        model.addAttribute("survey", survey);
        return "personal/survey_view"; // View for displaying survey details
    }*/
  @GetMapping("/survey/{id}")
  public String viewSurvey(@PathVariable("id") Long id, Model model) {
     // System.out.println("Survey ID: " + id);  // Log the ID to ensure it is correct

      Survey survey = surveyService.getSurveyById(id);
      if (survey == null) {
          model.addAttribute("error", "Survey not found with ID: " + id);
          return "error/404"; // Custom 404 page
      }
      model.addAttribute("survey", survey);
      return "personal/survey_view"; // View for survey details
  }


    @GetMapping("/survey/delete/{id}")
    public String deleteSurvey(@PathVariable("id") Long id) {
        surveyService.deleteSurveyById(id);
        return "redirect:/surveys"; // Redirect to survey list after deletion
    }

    @GetMapping("/survey/update/{id}")
    public String showUpdateSurveyForm(@PathVariable("id") Long id, Model model) {
        Survey survey = surveyService.getSurveyById(id);
        if (survey == null) {
            model.addAttribute("error", "Survey not found with ID: " + id);
            return "error/404"; // Custom 404 page
        }
        model.addAttribute("survey", survey);
        return "personal/survey_update"; // View for updating survey
    }

   /* @PostMapping("/survey/update")
    public String updateSurvey(@RequestParam("id") Long id,
                               @RequestParam("name") String name,
                               @RequestParam("email") String email,
                               @RequestParam("feedback") String feedback,
                               @RequestParam("feedbackFile") MultipartFile feedbackFile,
                               Model model) {
        try {
            surveyService.updateSurvey(id, name, email, feedback, feedbackFile);
            return "redirect:/survey/" + id; // Redirect to survey details page
        } catch (Exception e) {
            model.addAttribute("error", "Failed to update survey: " + e.getMessage());
            return "personal/survey_update";
        }
    }*/
   @PostMapping("/survey/update")
   public String updateSurvey(@RequestParam("id") Long id,
                              @RequestParam("name") String name,
                              @RequestParam("email") String email,
                              @RequestParam("feedback") String feedback,
                              @RequestParam("feedbackFile") MultipartFile feedbackFile,
                              Model model) {
       try {
           surveyService.updateSurvey(id, name, email, feedback, feedbackFile);
           return "redirect:/survey/" + id; // Redirect to survey details page
       } catch (Exception e) {
           model.addAttribute("error", "Failed to update survey: " + e.getMessage());
           return "personal/survey_update";
       }
   }

}
