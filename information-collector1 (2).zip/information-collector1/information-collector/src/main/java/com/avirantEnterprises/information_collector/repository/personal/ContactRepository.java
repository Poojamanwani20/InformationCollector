package com.avirantEnterprises.information_collector.repository.personal;


//package com.avirantEnterprises.information_collector.repository.contact;

import org.springframework.data.jpa.repository.JpaRepository;
import com.avirantEnterprises.information_collector.model.personal.Contact;

public interface ContactRepository extends JpaRepository<Contact, Long> {
}

