package com.avirantEnterprises.information_collector.controller.personal;

import com.avirantEnterprises.information_collector.model.personal.Contact;
import com.avirantEnterprises.information_collector.service.personal.ContactService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Controller
public class ContactController {

    @Autowired
    private ContactService contactService;

    /**
     * Display the contact registration form.
     */
    @GetMapping("/contact_form")
    public String showContactRegistrationForm(Model model) {
        model.addAttribute("contact", new Contact()); // Pass an empty Contact object
        return "personal/contact_form"; // The view that displays the form
    }

    /**
     * Submit a new contact registration.
     */
    @PostMapping("/contact")
    public String registerContact(@RequestParam("name") String name,
                                  @RequestParam("email") String email,
                                  @RequestParam("phone") String phone,
                                  @RequestParam("message") String message,
                                  @RequestParam("document") MultipartFile document,
                                  Model model) {
        try {
            contactService.registerContact(name, email, phone, message, document);
            return "redirect:/contacts"; // Redirect to the contact list
        } catch (Exception e) {
            model.addAttribute("error", "Failed to register contact: " + e.getMessage());
            return "personal/contact_form"; // Return to form with error message
        }
    }

    /**
     * View a specific contact profile.
     */
    @GetMapping("/contact/{id}")
    public String viewContactProfile(@PathVariable("id") Long id, Model model) {
        Contact contact = contactService.getContactById(id);
        if (contact == null) {
            model.addAttribute("error", "Contact not found with ID: " + id);
            return "personal/contact_not_found"; // Custom error page for missing contact
        }
        model.addAttribute("contact", contact);
        return "personal/contact_details"; // View to display the contact profile
    }

    /**
     * Delete a contact profile.
     */
    @GetMapping("/contact/delete/{id}")
    public String deleteContactProfile(@PathVariable("id") Long id, Model model) {
        try {
            contactService.deleteContactById(id);
            return "redirect:/contacts"; // Redirect to the contact list after deletion
        } catch (Exception e) {
            model.addAttribute("error", "Failed to delete contact with ID: " + id);
            return "personal/contact_list"; // Return to list with error message
        }
    }

    /**
     * List all contacts.
     */
    @GetMapping("/contacts")
    public String listContacts(Model model) {
        List<Contact> contacts = contactService.getAllContacts();
        model.addAttribute("contacts", contacts);
        return "personal/contact_list"; // View to display the list of contacts
    }

    /**
     * Show the update form for a contact profile.
     */
    @GetMapping("/contact/update/{id}")
    public String showUpdateContactForm(@PathVariable("id") Long id, Model model) {
        Contact contact = contactService.getContactById(id);
        if (contact == null) {
            model.addAttribute("error", "Contact not found with ID: " + id);
            return "personal/contact_not_found"; // Custom error page for missing contact
        }
        model.addAttribute("contact", contact);
        return "personal/contact_update"; // View to display the update form
    }

    /**
     * Update a contact profile.
     */
    @PostMapping("/contact/update")
    public String updateContact(@RequestParam("id") Long id,
                                @RequestParam("name") String name,
                                @RequestParam("email") String email,
                                @RequestParam("phone") String phone,
                                @RequestParam("message") String message,
                                @RequestParam("document") MultipartFile document,
                                Model model) {
        try {
            contactService.updateContactProfile(id, name, email, phone, message, document);
            return "redirect:/contact/" + id; // Redirect to the updated contact profile
        } catch (Exception e) {
            model.addAttribute("error", "Failed to update contact: " + e.getMessage());
            return "personal/contact_update"; // Return to form with error message
        }
    }
}
