package com.avirantEnterprises.information_collector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InformationCollectorApplicationTests {

	@Test
	void contextLoads() {
	}

}
